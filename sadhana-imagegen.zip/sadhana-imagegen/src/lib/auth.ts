import { SignJWT, jwtVerify } from 'jose';
import { cookies } from 'next/headers';

// Simple hardcoded credentials - change these!
const CREDENTIALS = {
  username: 'sadhana',
  password: 'Sadhana@2026',
};

const JWT_SECRET = new TextEncoder().encode(
  process.env.JWT_SECRET || 'sadhana-imagegen-secret-key-change-this'
);

export async function createToken(username: string) {
  return await new SignJWT({ username })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime('7d')
    .sign(JWT_SECRET);
}

export async function verifyToken(token: string) {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET);
    return payload;
  } catch {
    return null;
  }
}

export function validateCredentials(username: string, password: string) {
  return username === CREDENTIALS.username && password === CREDENTIALS.password;
}

export async function isAuthenticated() {
  const cookieStore = cookies();
  const token = cookieStore.get('auth-token')?.value;
  
  if (!token) return false;
  
  const payload = await verifyToken(token);
  return !!payload;
}
