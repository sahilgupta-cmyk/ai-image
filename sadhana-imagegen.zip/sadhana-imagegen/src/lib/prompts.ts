// Style presets for different image types
export const STYLE_PRESETS = {
  spiritual: {
    name: 'Spiritual / Vedic',
    description: 'Divine, sacred, ethereal atmosphere',
    modifiers: 'divine radiance, sacred atmosphere, ethereal glow, celestial lighting, spiritual aura, devotional art style, traditional Indian aesthetics, intricate details, golden accents, mystical ambiance',
    negative: 'cartoon, anime, low quality, blurry, distorted, ugly, modern, western',
  },
  realistic: {
    name: 'Photorealistic',
    description: 'High-quality photographic style',
    modifiers: 'photorealistic, 8k, highly detailed, professional photography, perfect lighting, sharp focus, DSLR quality, cinematic, hyperrealistic',
    negative: 'illustration, cartoon, painting, drawing, anime, low quality, blurry',
  },
  illustrated: {
    name: 'Illustrated',
    description: 'Artistic illustration style',
    modifiers: 'detailed illustration, digital art, vibrant colors, artistic, stylized, beautiful composition, professional artwork, trending on artstation',
    negative: 'photo, photograph, realistic, blurry, low quality',
  },
  cinematic: {
    name: 'Cinematic',
    description: 'Movie-like dramatic visuals',
    modifiers: 'cinematic lighting, dramatic atmosphere, movie scene, epic composition, volumetric lighting, depth of field, anamorphic lens, film grain, blockbuster quality',
    negative: 'flat lighting, boring, simple, cartoon, anime',
  },
  traditional: {
    name: 'Traditional Art',
    description: 'Classic Indian art styles',
    modifiers: 'traditional Indian painting, Tanjore art style, miniature painting, intricate patterns, gold leaf details, rich colors, classical composition, heritage art',
    negative: 'modern, digital, western, cartoon, anime, photo',
  },
  minimal: {
    name: 'Minimal / Clean',
    description: 'Simple, clean aesthetics',
    modifiers: 'minimalist, clean design, simple composition, elegant, refined, subtle colors, modern aesthetic, uncluttered',
    negative: 'busy, cluttered, complex, noisy, chaotic',
  },
};

export const ASPECT_RATIOS = {
  '1:1': { width: 1024, height: 1024, label: 'Square (Social)' },
  '16:9': { width: 1344, height: 768, label: 'Landscape (Banner)' },
  '9:16': { width: 768, height: 1344, label: 'Portrait (Story)' },
  '4:5': { width: 896, height: 1120, label: 'Portrait (Instagram)' },
  '3:2': { width: 1216, height: 832, label: 'Landscape (Photo)' },
  '2:3': { width: 832, height: 1216, label: 'Portrait (Pinterest)' },
};

// Spiritual/Sadhana specific prompt enhancers
const DEITY_KEYWORDS = [
  'shiva', 'vishnu', 'brahma', 'ganesh', 'ganesha', 'krishna', 'rama', 'hanuman',
  'durga', 'lakshmi', 'saraswati', 'parvati', 'kali', 'radha', 'sita',
  'devi', 'shakti', 'murugan', 'kartikeya', 'narasimha', 'venkateswara'
];

const FESTIVAL_KEYWORDS = [
  'diwali', 'holi', 'navratri', 'durga puja', 'ganesh chaturthi', 'janmashtami',
  'mahashivratri', 'ram navami', 'hanuman jayanti', 'guru purnima', 'makar sankranti',
  'pongal', 'onam', 'baisakhi', 'raksha bandhan', 'karwa chauth'
];

function detectContext(prompt: string): { isSpiritual: boolean; hasDeity: boolean; hasFestival: boolean } {
  const lowerPrompt = prompt.toLowerCase();
  
  const hasDeity = DEITY_KEYWORDS.some(deity => lowerPrompt.includes(deity));
  const hasFestival = FESTIVAL_KEYWORDS.some(festival => lowerPrompt.includes(festival));
  const spiritualKeywords = ['temple', 'puja', 'mantra', 'meditation', 'yoga', 'sacred', 'divine', 'spiritual', 'vedic', 'hindu'];
  const isSpiritual = hasDeity || hasFestival || spiritualKeywords.some(kw => lowerPrompt.includes(kw));
  
  return { isSpiritual, hasDeity, hasFestival };
}

export function enhancePrompt(
  basePrompt: string,
  styleKey: keyof typeof STYLE_PRESETS = 'spiritual'
): { prompt: string; negativePrompt: string } {
  const style = STYLE_PRESETS[styleKey];
  const context = detectContext(basePrompt);
  
  let enhancedPrompt = basePrompt.trim();
  
  // Add spiritual enhancements for deity/festival images
  if (context.hasDeity && styleKey === 'spiritual') {
    enhancedPrompt += ', divine presence, sacred iconography, traditional attributes';
  }
  
  if (context.hasFestival && styleKey === 'spiritual') {
    enhancedPrompt += ', festive atmosphere, celebration, traditional decorations, joyful ambiance';
  }
  
  // Add style modifiers
  enhancedPrompt += `, ${style.modifiers}`;
  
  // Quality boosters
  enhancedPrompt += ', masterpiece, best quality, ultra detailed';
  
  return {
    prompt: enhancedPrompt,
    negativePrompt: style.negative + ', watermark, signature, text, logo, worst quality, low quality, jpeg artifacts, deformed, mutated',
  };
}

// Generate multiple unique prompts for bulk generation
export function generateBulkPrompts(
  theme: string,
  count: number,
  styleKey: keyof typeof STYLE_PRESETS = 'spiritual'
): string[] {
  const variations = [
    'close-up view',
    'wide angle scene',
    'dramatic lighting',
    'soft morning light',
    'golden hour',
    'mystical atmosphere',
    'serene composition',
    'dynamic pose',
    'meditative scene',
    'vibrant colors',
    'subtle tones',
    'detailed background',
    'minimalist background',
    'devotional setting',
    'nature elements',
  ];
  
  const prompts: string[] = [];
  const shuffled = [...variations].sort(() => Math.random() - 0.5);
  
  for (let i = 0; i < count; i++) {
    const variation = shuffled[i % shuffled.length];
    prompts.push(`${theme}, ${variation}`);
  }
  
  return prompts;
}
