import Replicate from 'replicate';

const replicate = new Replicate({
  auth: process.env.REPLICATE_API_TOKEN,
});

// Flux Schnell - fast and cheap
const FLUX_SCHNELL = 'black-forest-labs/flux-schnell';

// Flux Dev - higher quality, slightly more expensive
const FLUX_DEV = 'black-forest-labs/flux-dev';

export interface GenerateImageParams {
  prompt: string;
  negativePrompt?: string;
  width?: number;
  height?: number;
  model?: 'schnell' | 'dev';
  seed?: number;
}

export interface GenerateImageResult {
  success: boolean;
  imageUrl?: string;
  error?: string;
  seed?: number;
}

export async function generateImage({
  prompt,
  negativePrompt,
  width = 1024,
  height = 1024,
  model = 'schnell',
  seed,
}: GenerateImageParams): Promise<GenerateImageResult> {
  try {
    const modelId = model === 'dev' ? FLUX_DEV : FLUX_SCHNELL;
    
    const input: Record<string, any> = {
      prompt,
      width,
      height,
      num_outputs: 1,
      output_format: 'webp',
      output_quality: 90,
    };
    
    // Flux Schnell specific params
    if (model === 'schnell') {
      input.num_inference_steps = 4;
      input.guidance_scale = 0; // Schnell doesn't use guidance
    }
    
    // Flux Dev specific params
    if (model === 'dev') {
      input.num_inference_steps = 28;
      input.guidance_scale = 3.5;
      if (negativePrompt) {
        input.negative_prompt = negativePrompt;
      }
    }
    
    // Add seed if provided for reproducibility
    if (seed !== undefined) {
      input.seed = seed;
    }
    
    const output = await replicate.run(modelId, { input });
    
    // Output is an array of URLs
    const imageUrl = Array.isArray(output) ? output[0] : output;
    
    if (!imageUrl || typeof imageUrl !== 'string') {
      throw new Error('No image URL returned from Replicate');
    }
    
    return {
      success: true,
      imageUrl,
      seed: input.seed,
    };
  } catch (error) {
    console.error('Replicate generation error:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
    };
  }
}

export async function generateMultipleImages(
  prompts: { prompt: string; negativePrompt?: string }[],
  width: number = 1024,
  height: number = 1024,
  model: 'schnell' | 'dev' = 'schnell'
): Promise<GenerateImageResult[]> {
  // Generate images in parallel with a concurrency limit
  const concurrencyLimit = 3;
  const results: GenerateImageResult[] = [];
  
  for (let i = 0; i < prompts.length; i += concurrencyLimit) {
    const batch = prompts.slice(i, i + concurrencyLimit);
    const batchResults = await Promise.all(
      batch.map(({ prompt, negativePrompt }) =>
        generateImage({ prompt, negativePrompt, width, height, model })
      )
    );
    results.push(...batchResults);
  }
  
  return results;
}
