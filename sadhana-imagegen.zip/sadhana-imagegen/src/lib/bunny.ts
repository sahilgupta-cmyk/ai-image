// BunnyCDN Storage API utilities

const BUNNY_STORAGE_ZONE = process.env.BUNNY_STORAGE_ZONE || 'vedic-images';
const BUNNY_STORAGE_PASSWORD = process.env.BUNNY_STORAGE_PASSWORD || '';
const BUNNY_CDN_URL = process.env.BUNNY_CDN_URL || 'https://vedic-images.b-cdn.net';
const BUNNY_STORAGE_REGION = process.env.BUNNY_STORAGE_REGION || ''; // Empty for Falkenstein, 'ny' for NY, etc.

function getStorageUrl() {
  const region = BUNNY_STORAGE_REGION ? `${BUNNY_STORAGE_REGION}.` : '';
  return `https://${region}storage.bunnycdn.com/${BUNNY_STORAGE_ZONE}`;
}

export async function uploadToBunny(
  imageUrl: string,
  filename: string,
  folder: string = 'ai-generated'
): Promise<{ success: boolean; cdnUrl?: string; error?: string }> {
  try {
    // Download image from Replicate
    const imageResponse = await fetch(imageUrl);
    if (!imageResponse.ok) {
      throw new Error('Failed to download image from source');
    }
    const imageBuffer = await imageResponse.arrayBuffer();
    
    // Generate organized path with date
    const date = new Date();
    const yearMonth = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
    const fullPath = `${folder}/${yearMonth}/${filename}`;
    
    // Upload to BunnyCDN
    const uploadUrl = `${getStorageUrl()}/${fullPath}`;
    
    const uploadResponse = await fetch(uploadUrl, {
      method: 'PUT',
      headers: {
        'AccessKey': BUNNY_STORAGE_PASSWORD,
        'Content-Type': 'image/webp',
      },
      body: imageBuffer,
    });
    
    if (!uploadResponse.ok) {
      const errorText = await uploadResponse.text();
      throw new Error(`BunnyCDN upload failed: ${uploadResponse.status} - ${errorText}`);
    }
    
    const cdnUrl = `${BUNNY_CDN_URL}/${fullPath}`;
    
    return { success: true, cdnUrl };
  } catch (error) {
    console.error('BunnyCDN upload error:', error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error' 
    };
  }
}

export async function listBunnyImages(
  folder: string = 'ai-generated',
  limit: number = 50
): Promise<{ success: boolean; images?: any[]; error?: string }> {
  try {
    const listUrl = `${getStorageUrl()}/${folder}/`;
    
    const response = await fetch(listUrl, {
      method: 'GET',
      headers: {
        'AccessKey': BUNNY_STORAGE_PASSWORD,
        'Accept': 'application/json',
      },
    });
    
    if (!response.ok) {
      throw new Error(`Failed to list images: ${response.status}`);
    }
    
    const items = await response.json();
    
    // Process and return images
    const images = items
      .filter((item: any) => !item.IsDirectory)
      .map((item: any) => ({
        name: item.ObjectName,
        path: item.Path,
        size: item.Length,
        created: item.DateCreated,
        cdnUrl: `${BUNNY_CDN_URL}${item.Path}/${item.ObjectName}`,
      }))
      .slice(0, limit);
    
    return { success: true, images };
  } catch (error) {
    console.error('BunnyCDN list error:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
    };
  }
}

export async function deleteBunnyImage(
  path: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const deleteUrl = `${getStorageUrl()}/${path}`;
    
    const response = await fetch(deleteUrl, {
      method: 'DELETE',
      headers: {
        'AccessKey': BUNNY_STORAGE_PASSWORD,
      },
    });
    
    if (!response.ok) {
      throw new Error(`Failed to delete: ${response.status}`);
    }
    
    return { success: true };
  } catch (error) {
    console.error('BunnyCDN delete error:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
    };
  }
}

export function generateFilename(prompt: string): string {
  // Create a clean filename from prompt
  const cleaned = prompt
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, '')
    .trim()
    .split(/\s+/)
    .slice(0, 5)
    .join('-');
  
  const timestamp = Date.now();
  const random = Math.random().toString(36).substring(2, 6);
  
  return `${cleaned}-${timestamp}-${random}.webp`;
}
