import { NextRequest, NextResponse } from 'next/server';
import { verifyToken } from '@/lib/auth';
import { generateImage } from '@/lib/replicate';
import { uploadToBunny, generateFilename } from '@/lib/bunny';
import { enhancePrompt, ASPECT_RATIOS, STYLE_PRESETS } from '@/lib/prompts';

export const maxDuration = 60; // Allow up to 60 seconds for generation

export async function POST(request: NextRequest) {
  try {
    // Check authentication
    const token = request.cookies.get('auth-token')?.value;
    if (!token || !(await verifyToken(token))) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    
    const body = await request.json();
    const { 
      prompt, 
      style = 'spiritual', 
      aspectRatio = '1:1',
      model = 'schnell',
      enhanceEnabled = true,
    } = body;
    
    if (!prompt) {
      return NextResponse.json({ error: 'Prompt required' }, { status: 400 });
    }
    
    // Get dimensions from aspect ratio
    const dimensions = ASPECT_RATIOS[aspectRatio as keyof typeof ASPECT_RATIOS] || ASPECT_RATIOS['1:1'];
    
    // Enhance prompt if enabled
    let finalPrompt = prompt;
    let negativePrompt = '';
    
    if (enhanceEnabled && style in STYLE_PRESETS) {
      const enhanced = enhancePrompt(prompt, style as keyof typeof STYLE_PRESETS);
      finalPrompt = enhanced.prompt;
      negativePrompt = enhanced.negativePrompt;
    }
    
    // Generate image
    const result = await generateImage({
      prompt: finalPrompt,
      negativePrompt,
      width: dimensions.width,
      height: dimensions.height,
      model: model as 'schnell' | 'dev',
    });
    
    if (!result.success || !result.imageUrl) {
      return NextResponse.json(
        { error: result.error || 'Generation failed' },
        { status: 500 }
      );
    }
    
    // Upload to BunnyCDN
    const filename = generateFilename(prompt);
    const uploadResult = await uploadToBunny(result.imageUrl, filename);
    
    if (!uploadResult.success) {
      // Return Replicate URL if Bunny upload fails
      return NextResponse.json({
        success: true,
        imageUrl: result.imageUrl,
        cdnUrl: null,
        prompt: finalPrompt,
        warning: 'Image generated but CDN upload failed. URL will expire.',
      });
    }
    
    return NextResponse.json({
      success: true,
      imageUrl: result.imageUrl,
      cdnUrl: uploadResult.cdnUrl,
      prompt: finalPrompt,
      style,
      aspectRatio,
    });
  } catch (error) {
    console.error('Generate API error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
