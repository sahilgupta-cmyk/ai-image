import { NextRequest, NextResponse } from 'next/server';
import { verifyToken } from '@/lib/auth';
import { generateImage } from '@/lib/replicate';
import { uploadToBunny, generateFilename } from '@/lib/bunny';
import { enhancePrompt, generateBulkPrompts, ASPECT_RATIOS, STYLE_PRESETS } from '@/lib/prompts';

export const maxDuration = 300; // Allow up to 5 minutes for bulk generation

interface BulkGenerationResult {
  index: number;
  prompt: string;
  enhancedPrompt: string;
  status: 'success' | 'failed';
  imageUrl?: string;
  cdnUrl?: string;
  error?: string;
}

export async function POST(request: NextRequest) {
  try {
    // Check authentication
    const token = request.cookies.get('auth-token')?.value;
    if (!token || !(await verifyToken(token))) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    
    const body = await request.json();
    const { 
      theme,
      prompts: customPrompts, // Array of custom prompts OR use theme to auto-generate
      count = 5,
      style = 'spiritual', 
      aspectRatio = '1:1',
      model = 'schnell',
      enhanceEnabled = true,
    } = body;
    
    if (!theme && (!customPrompts || customPrompts.length === 0)) {
      return NextResponse.json(
        { error: 'Either theme or prompts array required' },
        { status: 400 }
      );
    }
    
    // Limit to 10 images per batch
    const maxCount = Math.min(count, 10);
    
    // Generate prompts if not provided
    let promptList: string[] = customPrompts || generateBulkPrompts(
      theme,
      maxCount,
      style as keyof typeof STYLE_PRESETS
    );
    
    // Ensure we don't exceed max count
    promptList = promptList.slice(0, maxCount);
    
    // Get dimensions from aspect ratio
    const dimensions = ASPECT_RATIOS[aspectRatio as keyof typeof ASPECT_RATIOS] || ASPECT_RATIOS['1:1'];
    
    // Process each prompt
    const results: BulkGenerationResult[] = [];
    
    // Process in batches of 2 to avoid rate limits
    const batchSize = 2;
    
    for (let i = 0; i < promptList.length; i += batchSize) {
      const batch = promptList.slice(i, i + batchSize);
      
      const batchPromises = batch.map(async (prompt, batchIndex) => {
        const index = i + batchIndex;
        
        try {
          // Enhance prompt if enabled
          let finalPrompt = prompt;
          let negativePrompt = '';
          
          if (enhanceEnabled && style in STYLE_PRESETS) {
            const enhanced = enhancePrompt(prompt, style as keyof typeof STYLE_PRESETS);
            finalPrompt = enhanced.prompt;
            negativePrompt = enhanced.negativePrompt;
          }
          
          // Generate image
          const result = await generateImage({
            prompt: finalPrompt,
            negativePrompt,
            width: dimensions.width,
            height: dimensions.height,
            model: model as 'schnell' | 'dev',
          });
          
          if (!result.success || !result.imageUrl) {
            return {
              index,
              prompt,
              enhancedPrompt: finalPrompt,
              status: 'failed' as const,
              error: result.error || 'Generation failed',
            };
          }
          
          // Upload to BunnyCDN
          const filename = generateFilename(prompt);
          const uploadResult = await uploadToBunny(result.imageUrl, filename);
          
          return {
            index,
            prompt,
            enhancedPrompt: finalPrompt,
            status: 'success' as const,
            imageUrl: result.imageUrl,
            cdnUrl: uploadResult.success ? uploadResult.cdnUrl : undefined,
          };
        } catch (error) {
          return {
            index,
            prompt,
            enhancedPrompt: prompt,
            status: 'failed' as const,
            error: error instanceof Error ? error.message : 'Unknown error',
          };
        }
      });
      
      const batchResults = await Promise.all(batchPromises);
      results.push(...batchResults);
    }
    
    const successCount = results.filter(r => r.status === 'success').length;
    const failedCount = results.filter(r => r.status === 'failed').length;
    
    return NextResponse.json({
      success: true,
      total: results.length,
      successCount,
      failedCount,
      results,
      style,
      aspectRatio,
    });
  } catch (error) {
    console.error('Bulk generate API error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
