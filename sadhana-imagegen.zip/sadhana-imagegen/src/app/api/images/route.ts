import { NextRequest, NextResponse } from 'next/server';
import { verifyToken } from '@/lib/auth';
import { listBunnyImages, deleteBunnyImage } from '@/lib/bunny';

export async function GET(request: NextRequest) {
  try {
    // Check authentication
    const token = request.cookies.get('auth-token')?.value;
    if (!token || !(await verifyToken(token))) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    
    const searchParams = request.nextUrl.searchParams;
    const folder = searchParams.get('folder') || 'ai-generated';
    const limit = parseInt(searchParams.get('limit') || '50');
    
    const result = await listBunnyImages(folder, limit);
    
    if (!result.success) {
      return NextResponse.json(
        { error: result.error || 'Failed to list images' },
        { status: 500 }
      );
    }
    
    return NextResponse.json({
      success: true,
      images: result.images,
    });
  } catch (error) {
    console.error('List images API error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  try {
    // Check authentication
    const token = request.cookies.get('auth-token')?.value;
    if (!token || !(await verifyToken(token))) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    
    const { path } = await request.json();
    
    if (!path) {
      return NextResponse.json({ error: 'Path required' }, { status: 400 });
    }
    
    const result = await deleteBunnyImage(path);
    
    if (!result.success) {
      return NextResponse.json(
        { error: result.error || 'Failed to delete image' },
        { status: 500 }
      );
    }
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Delete image API error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
