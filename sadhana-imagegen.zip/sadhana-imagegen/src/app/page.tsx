'use client';

import { useState, useEffect } from 'react';

// Types
interface GeneratedImage {
  prompt: string;
  enhancedPrompt?: string;
  imageUrl: string;
  cdnUrl?: string;
  style?: string;
  aspectRatio?: string;
  createdAt: Date;
}

interface BulkResult {
  index: number;
  prompt: string;
  enhancedPrompt: string;
  status: 'success' | 'failed';
  imageUrl?: string;
  cdnUrl?: string;
  error?: string;
}

// Style presets
const STYLE_PRESETS = {
  spiritual: { name: 'Spiritual / Vedic', emoji: '🙏' },
  realistic: { name: 'Photorealistic', emoji: '📷' },
  illustrated: { name: 'Illustrated', emoji: '🎨' },
  cinematic: { name: 'Cinematic', emoji: '🎬' },
  traditional: { name: 'Traditional Art', emoji: '🖼️' },
  minimal: { name: 'Minimal / Clean', emoji: '✨' },
};

const ASPECT_RATIOS = {
  '1:1': { label: 'Square', desc: 'Social' },
  '16:9': { label: 'Landscape', desc: 'Banner' },
  '9:16': { label: 'Portrait', desc: 'Story' },
  '4:5': { label: 'Portrait', desc: 'Instagram' },
};

export default function Home() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'single' | 'bulk' | 'gallery'>('single');
  
  // Auth state
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [loginLoading, setLoginLoading] = useState(false);
  
  // Single generation state
  const [prompt, setPrompt] = useState('');
  const [style, setStyle] = useState('spiritual');
  const [aspectRatio, setAspectRatio] = useState('1:1');
  const [enhanceEnabled, setEnhanceEnabled] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [generatedImages, setGeneratedImages] = useState<GeneratedImage[]>([]);
  
  // Bulk generation state
  const [bulkTheme, setBulkTheme] = useState('');
  const [bulkCount, setBulkCount] = useState(5);
  const [bulkPrompts, setBulkPrompts] = useState<string[]>([]);
  const [bulkMode, setBulkMode] = useState<'theme' | 'custom'>('theme');
  const [bulkGenerating, setBulkGenerating] = useState(false);
  const [bulkResults, setBulkResults] = useState<BulkResult[]>([]);
  const [bulkProgress, setBulkProgress] = useState(0);
  
  // Gallery state
  const [galleryImages, setGalleryImages] = useState<any[]>([]);
  const [galleryLoading, setGalleryLoading] = useState(false);
  
  // Check auth on mount
  useEffect(() => {
    checkAuth();
  }, []);
  
  async function checkAuth() {
    try {
      const res = await fetch('/api/auth/check');
      const data = await res.json();
      setIsAuthenticated(data.authenticated);
    } catch (error) {
      setIsAuthenticated(false);
    } finally {
      setIsLoading(false);
    }
  }
  
  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setLoginLoading(true);
    setLoginError('');
    
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });
      
      if (res.ok) {
        setIsAuthenticated(true);
      } else {
        const data = await res.json();
        setLoginError(data.error || 'Login failed');
      }
    } catch (error) {
      setLoginError('Network error');
    } finally {
      setLoginLoading(false);
    }
  }
  
  async function handleLogout() {
    await fetch('/api/auth/logout', { method: 'POST' });
    setIsAuthenticated(false);
  }
  
  async function handleGenerate() {
    if (!prompt.trim()) return;
    
    setGenerating(true);
    
    try {
      const res = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          style,
          aspectRatio,
          enhanceEnabled,
        }),
      });
      
      const data = await res.json();
      
      if (data.success) {
        setGeneratedImages(prev => [{
          prompt,
          enhancedPrompt: data.prompt,
          imageUrl: data.cdnUrl || data.imageUrl,
          cdnUrl: data.cdnUrl,
          style,
          aspectRatio,
          createdAt: new Date(),
        }, ...prev]);
        setPrompt('');
      } else {
        alert(data.error || 'Generation failed');
      }
    } catch (error) {
      alert('Network error');
    } finally {
      setGenerating(false);
    }
  }
  
  async function handleBulkGenerate() {
    if (bulkMode === 'theme' && !bulkTheme.trim()) return;
    if (bulkMode === 'custom' && bulkPrompts.filter(p => p.trim()).length === 0) return;
    
    setBulkGenerating(true);
    setBulkResults([]);
    setBulkProgress(0);
    
    try {
      const res = await fetch('/api/bulk-generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          theme: bulkMode === 'theme' ? bulkTheme : undefined,
          prompts: bulkMode === 'custom' ? bulkPrompts.filter(p => p.trim()) : undefined,
          count: bulkCount,
          style,
          aspectRatio,
          enhanceEnabled,
        }),
      });
      
      const data = await res.json();
      
      if (data.success) {
        setBulkResults(data.results);
        setBulkProgress(100);
      } else {
        alert(data.error || 'Bulk generation failed');
      }
    } catch (error) {
      alert('Network error');
    } finally {
      setBulkGenerating(false);
    }
  }
  
  async function loadGallery() {
    setGalleryLoading(true);
    
    try {
      const res = await fetch('/api/images');
      const data = await res.json();
      
      if (data.success) {
        setGalleryImages(data.images || []);
      }
    } catch (error) {
      console.error('Failed to load gallery');
    } finally {
      setGalleryLoading(false);
    }
  }
  
  useEffect(() => {
    if (activeTab === 'gallery' && isAuthenticated) {
      loadGallery();
    }
  }, [activeTab, isAuthenticated]);
  
  function downloadImage(url: string, filename: string) {
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.target = '_blank';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-sadhana-gold border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-sadhana-cream/60">Loading...</p>
        </div>
      </div>
    );
  }
  
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="glass-card rounded-2xl p-8 w-full max-w-md">
          <div className="text-center mb-8">
            <div className="text-4xl mb-3">🙏</div>
            <h1 className="font-display text-3xl font-bold text-sadhana-gold mb-2">Sadhana ImageGen</h1>
            <p className="text-sadhana-cream/60">AI-powered spiritual image creation</p>
          </div>
          
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Username</label>
              <input
                type="text"
                value={username}
                onChange={e => setUsername(e.target.value)}
                className="w-full px-4 py-3 bg-sadhana-deep/50 border border-sadhana-cream/20 rounded-lg focus:outline-none focus:border-sadhana-gold transition-colors"
                placeholder="Enter username"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-2">Password</label>
              <input
                type="password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                className="w-full px-4 py-3 bg-sadhana-deep/50 border border-sadhana-cream/20 rounded-lg focus:outline-none focus:border-sadhana-gold transition-colors"
                placeholder="Enter password"
              />
            </div>
            
            {loginError && (
              <p className="text-red-400 text-sm text-center">{loginError}</p>
            )}
            
            <button
              type="submit"
              disabled={loginLoading}
              className="w-full py-3 bg-gradient-to-r from-sadhana-gold to-yellow-600 text-sadhana-deep font-semibold rounded-lg hover:opacity-90 transition-opacity disabled:opacity-50"
            >
              {loginLoading ? 'Signing in...' : 'Sign In'}
            </button>
          </form>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="border-b border-sadhana-cream/10 bg-sadhana-deep/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-2xl">🙏</span>
            <h1 className="font-display text-xl font-bold text-sadhana-gold">Sadhana ImageGen</h1>
          </div>
          
          <nav className="flex items-center gap-2">
            {(['single', 'bulk', 'gallery'] as const).map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-4 py-2 rounded-lg font-medium transition-all ${
                  activeTab === tab
                    ? 'bg-sadhana-gold text-sadhana-deep'
                    : 'text-sadhana-cream/70 hover:text-sadhana-cream hover:bg-sadhana-cream/10'
                }`}
              >
                {tab === 'single' && '✨ Single'}
                {tab === 'bulk' && '📦 Bulk'}
                {tab === 'gallery' && '🖼️ Gallery'}
              </button>
            ))}
          </nav>
          
          <button
            onClick={handleLogout}
            className="px-4 py-2 text-sadhana-cream/60 hover:text-sadhana-cream transition-colors"
          >
            Logout
          </button>
        </div>
      </header>
      
      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Single Generation Tab */}
        {activeTab === 'single' && (
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Controls */}
            <div className="glass-card rounded-2xl p-6 space-y-6">
              <div>
                <label className="block text-sm font-medium mb-2">Describe your image</label>
                <textarea
                  value={prompt}
                  onChange={e => setPrompt(e.target.value)}
                  placeholder="e.g., Lord Ganesh blessing devotees with divine golden aura"
                  rows={4}
                  className="w-full px-4 py-3 bg-sadhana-deep/50 border border-sadhana-cream/20 rounded-lg focus:outline-none focus:border-sadhana-gold transition-colors resize-none"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-3">Style</label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {Object.entries(STYLE_PRESETS).map(([key, { name, emoji }]) => (
                    <button
                      key={key}
                      onClick={() => setStyle(key)}
                      className={`px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                        style === key
                          ? 'bg-sadhana-gold text-sadhana-deep'
                          : 'bg-sadhana-cream/10 hover:bg-sadhana-cream/20'
                      }`}
                    >
                      {emoji} {name}
                    </button>
                  ))}
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-3">Aspect Ratio</label>
                <div className="grid grid-cols-4 gap-2">
                  {Object.entries(ASPECT_RATIOS).map(([key, { label, desc }]) => (
                    <button
                      key={key}
                      onClick={() => setAspectRatio(key)}
                      className={`px-3 py-2 rounded-lg text-sm transition-all ${
                        aspectRatio === key
                          ? 'bg-sadhana-gold text-sadhana-deep'
                          : 'bg-sadhana-cream/10 hover:bg-sadhana-cream/20'
                      }`}
                    >
                      <div className="font-medium">{key}</div>
                      <div className="text-xs opacity-70">{desc}</div>
                    </button>
                  ))}
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <input
                  type="checkbox"
                  id="enhance"
                  checked={enhanceEnabled}
                  onChange={e => setEnhanceEnabled(e.target.checked)}
                  className="w-4 h-4 rounded"
                />
                <label htmlFor="enhance" className="text-sm">
                  Auto-enhance prompt with style modifiers
                </label>
              </div>
              
              <button
                onClick={handleGenerate}
                disabled={generating || !prompt.trim()}
                className="w-full py-4 bg-gradient-to-r from-sadhana-gold to-yellow-600 text-sadhana-deep font-bold text-lg rounded-xl hover:opacity-90 transition-opacity disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {generating ? (
                  <>
                    <div className="w-5 h-5 border-2 border-sadhana-deep border-t-transparent rounded-full animate-spin"></div>
                    Generating...
                  </>
                ) : (
                  <>✨ Generate Image</>
                )}
              </button>
            </div>
            
            {/* Results */}
            <div className="space-y-4">
              <h2 className="font-display text-xl font-semibold">Generated Images</h2>
              
              {generatedImages.length === 0 ? (
                <div className="glass-card rounded-2xl p-12 text-center">
                  <div className="text-4xl mb-4">🎨</div>
                  <p className="text-sadhana-cream/60">Your generated images will appear here</p>
                </div>
              ) : (
                <div className="space-y-4 max-h-[600px] overflow-y-auto pr-2">
                  {generatedImages.map((img, idx) => (
                    <div key={idx} className="glass-card rounded-xl overflow-hidden fade-in">
                      <img
                        src={img.imageUrl}
                        alt={img.prompt}
                        className="w-full aspect-square object-cover"
                      />
                      <div className="p-4">
                        <p className="text-sm text-sadhana-cream/80 mb-3 line-clamp-2">{img.prompt}</p>
                        <div className="flex gap-2">
                          <button
                            onClick={() => downloadImage(img.imageUrl, `sadhana-${Date.now()}.webp`)}
                            className="flex-1 py-2 bg-sadhana-gold/20 hover:bg-sadhana-gold/30 rounded-lg text-sm font-medium transition-colors"
                          >
                            ⬇️ Download
                          </button>
                          <button
                            onClick={() => {
                              navigator.clipboard.writeText(img.enhancedPrompt || img.prompt);
                              alert('Prompt copied!');
                            }}
                            className="flex-1 py-2 bg-sadhana-cream/10 hover:bg-sadhana-cream/20 rounded-lg text-sm font-medium transition-colors"
                          >
                            📋 Copy Prompt
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
        
        {/* Bulk Generation Tab */}
        {activeTab === 'bulk' && (
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Bulk Controls */}
            <div className="glass-card rounded-2xl p-6 space-y-6">
              <div>
                <label className="block text-sm font-medium mb-3">Generation Mode</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setBulkMode('theme')}
                    className={`px-4 py-3 rounded-lg font-medium transition-all ${
                      bulkMode === 'theme'
                        ? 'bg-sadhana-gold text-sadhana-deep'
                        : 'bg-sadhana-cream/10 hover:bg-sadhana-cream/20'
                    }`}
                  >
                    🎯 Theme-based
                  </button>
                  <button
                    onClick={() => setBulkMode('custom')}
                    className={`px-4 py-3 rounded-lg font-medium transition-all ${
                      bulkMode === 'custom'
                        ? 'bg-sadhana-gold text-sadhana-deep'
                        : 'bg-sadhana-cream/10 hover:bg-sadhana-cream/20'
                    }`}
                  >
                    ✏️ Custom Prompts
                  </button>
                </div>
              </div>
              
              {bulkMode === 'theme' ? (
                <>
                  <div>
                    <label className="block text-sm font-medium mb-2">Theme</label>
                    <input
                      type="text"
                      value={bulkTheme}
                      onChange={e => setBulkTheme(e.target.value)}
                      placeholder="e.g., Navratri celebration images for social media"
                      className="w-full px-4 py-3 bg-sadhana-deep/50 border border-sadhana-cream/20 rounded-lg focus:outline-none focus:border-sadhana-gold transition-colors"
                    />
                    <p className="text-xs text-sadhana-cream/50 mt-2">
                      We'll automatically create {bulkCount} unique variations based on this theme
                    </p>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium mb-2">Number of Images: {bulkCount}</label>
                    <input
                      type="range"
                      min={2}
                      max={10}
                      value={bulkCount}
                      onChange={e => setBulkCount(parseInt(e.target.value))}
                      className="w-full"
                    />
                    <div className="flex justify-between text-xs text-sadhana-cream/50">
                      <span>2</span>
                      <span>10</span>
                    </div>
                  </div>
                </>
              ) : (
                <div>
                  <label className="block text-sm font-medium mb-2">Custom Prompts (one per line)</label>
                  <textarea
                    value={bulkPrompts.join('\n')}
                    onChange={e => setBulkPrompts(e.target.value.split('\n'))}
                    placeholder={`Lord Shiva meditating in Himalayas\nGoddess Durga with lion\nLord Krishna playing flute\nGanesh with modak`}
                    rows={8}
                    className="w-full px-4 py-3 bg-sadhana-deep/50 border border-sadhana-cream/20 rounded-lg focus:outline-none focus:border-sadhana-gold transition-colors resize-none font-mono text-sm"
                  />
                  <p className="text-xs text-sadhana-cream/50 mt-2">
                    {bulkPrompts.filter(p => p.trim()).length} prompts entered (max 10)
                  </p>
                </div>
              )}
              
              <div>
                <label className="block text-sm font-medium mb-3">Style</label>
                <div className="grid grid-cols-3 gap-2">
                  {Object.entries(STYLE_PRESETS).map(([key, { name, emoji }]) => (
                    <button
                      key={key}
                      onClick={() => setStyle(key)}
                      className={`px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                        style === key
                          ? 'bg-sadhana-gold text-sadhana-deep'
                          : 'bg-sadhana-cream/10 hover:bg-sadhana-cream/20'
                      }`}
                    >
                      {emoji} {name}
                    </button>
                  ))}
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-3">Aspect Ratio</label>
                <div className="grid grid-cols-4 gap-2">
                  {Object.entries(ASPECT_RATIOS).map(([key, { label, desc }]) => (
                    <button
                      key={key}
                      onClick={() => setAspectRatio(key)}
                      className={`px-3 py-2 rounded-lg text-sm transition-all ${
                        aspectRatio === key
                          ? 'bg-sadhana-gold text-sadhana-deep'
                          : 'bg-sadhana-cream/10 hover:bg-sadhana-cream/20'
                      }`}
                    >
                      <div className="font-medium">{key}</div>
                      <div className="text-xs opacity-70">{desc}</div>
                    </button>
                  ))}
                </div>
              </div>
              
              <button
                onClick={handleBulkGenerate}
                disabled={bulkGenerating || (bulkMode === 'theme' ? !bulkTheme.trim() : bulkPrompts.filter(p => p.trim()).length === 0)}
                className="w-full py-4 bg-gradient-to-r from-sadhana-gold to-yellow-600 text-sadhana-deep font-bold text-lg rounded-xl hover:opacity-90 transition-opacity disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {bulkGenerating ? (
                  <>
                    <div className="w-5 h-5 border-2 border-sadhana-deep border-t-transparent rounded-full animate-spin"></div>
                    Generating {bulkMode === 'theme' ? bulkCount : bulkPrompts.filter(p => p.trim()).length} images...
                  </>
                ) : (
                  <>📦 Generate All Images</>
                )}
              </button>
              
              {bulkGenerating && (
                <div className="text-center text-sm text-sadhana-cream/60">
                  This may take a few minutes. Please don't close the page.
                </div>
              )}
            </div>
            
            {/* Bulk Results */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="font-display text-xl font-semibold">Bulk Results</h2>
                {bulkResults.length > 0 && (
                  <span className="text-sm text-sadhana-cream/60">
                    {bulkResults.filter(r => r.status === 'success').length}/{bulkResults.length} successful
                  </span>
                )}
              </div>
              
              {bulkResults.length === 0 ? (
                <div className="glass-card rounded-2xl p-12 text-center">
                  <div className="text-4xl mb-4">📦</div>
                  <p className="text-sadhana-cream/60">Bulk generated images will appear here</p>
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-4 max-h-[600px] overflow-y-auto pr-2">
                  {bulkResults.map((result, idx) => (
                    <div key={idx} className={`glass-card rounded-xl overflow-hidden fade-in ${result.status === 'failed' ? 'opacity-50' : ''}`}>
                      {result.status === 'success' && result.imageUrl ? (
                        <>
                          <img
                            src={result.cdnUrl || result.imageUrl}
                            alt={result.prompt}
                            className="w-full aspect-square object-cover"
                          />
                          <div className="p-3">
                            <p className="text-xs text-sadhana-cream/70 mb-2 line-clamp-2">{result.prompt}</p>
                            <button
                              onClick={() => downloadImage(result.cdnUrl || result.imageUrl!, `bulk-${idx + 1}.webp`)}
                              className="w-full py-1.5 bg-sadhana-gold/20 hover:bg-sadhana-gold/30 rounded text-xs font-medium transition-colors"
                            >
                              ⬇️ Download
                            </button>
                          </div>
                        </>
                      ) : (
                        <div className="aspect-square flex items-center justify-center bg-red-900/20">
                          <div className="text-center p-4">
                            <div className="text-2xl mb-2">❌</div>
                            <p className="text-xs text-red-400">{result.error || 'Failed'}</p>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
        
        {/* Gallery Tab */}
        {activeTab === 'gallery' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-2xl font-semibold">Image Gallery</h2>
              <button
                onClick={loadGallery}
                disabled={galleryLoading}
                className="px-4 py-2 bg-sadhana-cream/10 hover:bg-sadhana-cream/20 rounded-lg transition-colors flex items-center gap-2"
              >
                {galleryLoading ? (
                  <div className="w-4 h-4 border-2 border-sadhana-cream border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  '🔄'
                )}
                Refresh
              </button>
            </div>
            
            {galleryLoading ? (
              <div className="glass-card rounded-2xl p-12 text-center">
                <div className="w-12 h-12 border-4 border-sadhana-gold border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                <p className="text-sadhana-cream/60">Loading images from BunnyCDN...</p>
              </div>
            ) : galleryImages.length === 0 ? (
              <div className="glass-card rounded-2xl p-12 text-center">
                <div className="text-4xl mb-4">🖼️</div>
                <p className="text-sadhana-cream/60">No images found in BunnyCDN storage</p>
                <p className="text-sm text-sadhana-cream/40 mt-2">Generated images will appear here after upload</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {galleryImages.map((img, idx) => (
                  <div key={idx} className="glass-card rounded-xl overflow-hidden group">
                    <div className="relative">
                      <img
                        src={img.cdnUrl}
                        alt={img.name}
                        className="w-full aspect-square object-cover"
                      />
                      <div className="absolute inset-0 bg-sadhana-deep/80 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                        <button
                          onClick={() => downloadImage(img.cdnUrl, img.name)}
                          className="px-3 py-2 bg-sadhana-gold text-sadhana-deep rounded-lg text-sm font-medium"
                        >
                          ⬇️ Download
                        </button>
                      </div>
                    </div>
                    <div className="p-3">
                      <p className="text-xs text-sadhana-cream/60 truncate">{img.name}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
