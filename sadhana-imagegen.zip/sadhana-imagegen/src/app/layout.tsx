import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Sadhana Image Generator',
  description: 'AI-powered image generation for spiritual content',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="min-h-screen text-sadhana-cream">
        {children}
      </body>
    </html>
  );
}
