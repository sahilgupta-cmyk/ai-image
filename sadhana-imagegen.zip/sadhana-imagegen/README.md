# 🙏 Sadhana ImageGen

AI-powered image generation for spiritual content. Built with Next.js, Replicate (Flux), and BunnyCDN.

![Sadhana ImageGen](https://via.placeholder.com/800x400/330005/fcf4e2?text=Sadhana+ImageGen)

## Features

- ✨ **Single Image Generation** — Create one image at a time with full control
- 📦 **Bulk Generation** — Generate up to 10 images at once (theme-based or custom prompts)
- 🖼️ **Image Gallery** — View and manage all generated images from BunnyCDN
- 🎨 **Style Presets** — Spiritual, Realistic, Illustrated, Cinematic, Traditional, Minimal
- 📐 **Aspect Ratios** — Square (1:1), Landscape (16:9), Portrait (9:16, 4:5)
- 🔒 **Simple Auth** — Password-protected access
- ☁️ **Auto Upload** — Images automatically saved to BunnyCDN

## Quick Start

### 1. Get API Keys

**Replicate (for image generation):**
1. Go to https://replicate.com
2. Sign up/login
3. Go to https://replicate.com/account/api-tokens
4. Create new token → Copy it

**BunnyCDN (you already have this):**
1. Go to https://dash.bunny.net/storage
2. Select your storage zone (vedic-images)
3. Go to FTP & API Access → Copy password
4. Note your Pull Zone URL (e.g., https://vedic-images.b-cdn.net)

### 2. Deploy to Vercel

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/YOUR_USERNAME/sadhana-imagegen)

**Or manually:**

```bash
# Install Vercel CLI
npm i -g vercel

# Login to Vercel
vercel login

# Deploy
cd sadhana-imagegen
vercel
```

### 3. Add Environment Variables

In Vercel Dashboard → Your Project → Settings → Environment Variables:

| Variable | Value |
|----------|-------|
| `REPLICATE_API_TOKEN` | Your Replicate API token |
| `BUNNY_STORAGE_ZONE` | `vedic-images` |
| `BUNNY_STORAGE_PASSWORD` | Your BunnyCDN storage password |
| `BUNNY_CDN_URL` | `https://vedic-images.b-cdn.net` |
| `JWT_SECRET` | Any random string (for security) |

### 4. Login

```
Username: sadhana
Password: Sadhana@2026
```

## Local Development

```bash
# Clone the repo
git clone https://github.com/YOUR_USERNAME/sadhana-imagegen
cd sadhana-imagegen

# Install dependencies
npm install

# Create .env.local file
cp .env.example .env.local
# Edit .env.local with your API keys

# Run development server
npm run dev
```

Open http://localhost:3000

## Configuration

### Change Login Credentials

Edit `src/lib/auth.ts`:

```typescript
const CREDENTIALS = {
  username: 'your-username',
  password: 'your-secure-password',
};
```

### Add More Style Presets

Edit `src/lib/prompts.ts`:

```typescript
export const STYLE_PRESETS = {
  // Add your custom styles
  mythological: {
    name: 'Mythological',
    description: 'Epic mythological scenes',
    modifiers: 'epic mythology, ancient legends, dramatic, divine...',
    negative: 'modern, cartoon...',
  },
};
```

## Cost Breakdown

| Service | Cost |
|---------|------|
| Vercel Hosting | Free |
| Replicate (Flux Schnell) | ~$0.003/image (~₹0.25) |
| BunnyCDN | You already have |

**Example: 100 images/month = ~₹25**

## Tech Stack

- **Framework:** Next.js 14 (App Router)
- **Styling:** Tailwind CSS
- **Image Gen:** Replicate (Flux Schnell)
- **Storage:** BunnyCDN
- **Auth:** JWT (jose)
- **Hosting:** Vercel

## API Routes

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/auth/login` | POST | Login |
| `/api/auth/logout` | POST | Logout |
| `/api/auth/check` | GET | Check auth status |
| `/api/generate` | POST | Generate single image |
| `/api/bulk-generate` | POST | Generate multiple images |
| `/api/images` | GET | List images from BunnyCDN |
| `/api/images` | DELETE | Delete image from BunnyCDN |

## Folder Structure

```
sadhana-imagegen/
├── src/
│   ├── app/
│   │   ├── api/
│   │   │   ├── auth/
│   │   │   ├── generate/
│   │   │   ├── bulk-generate/
│   │   │   └── images/
│   │   ├── globals.css
│   │   ├── layout.tsx
│   │   └── page.tsx
│   └── lib/
│       ├── auth.ts
│       ├── bunny.ts
│       ├── prompts.ts
│       └── replicate.ts
├── .env.example
├── next.config.js
├── package.json
├── tailwind.config.js
└── README.md
```

## Troubleshooting

**Images not uploading to BunnyCDN?**
- Check your storage password is correct
- Verify the storage zone name matches
- Check BunnyCDN dashboard for errors

**Generation failing?**
- Verify Replicate API token is valid
- Check Replicate dashboard for usage/errors
- Ensure you have credits in Replicate

**Login not working?**
- Clear browser cookies
- Check credentials in `src/lib/auth.ts`

## Support

For issues or questions, contact the Sadhana team.

---

Made with 🙏 for Sadhana
